﻿namespace XFramework.BLL.Services.Abstracts
{
    public interface IRegister
    {
    }
}
