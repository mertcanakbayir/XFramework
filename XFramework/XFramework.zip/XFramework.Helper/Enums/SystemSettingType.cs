﻿namespace XFramework.Helper.Enums
{
    public enum SystemSettingType
    {
        String,
        Int,
        Bool,
        DateTime
    }
}