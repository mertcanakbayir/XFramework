﻿namespace XFramework.Helper.Enums
{
    public enum MailSettingKeys
    {
        SmtpHost,
        SmtpPort,
        SmtpUser,
        EncryptedPassword,
        EnableSsl,
        SenderEmail,
        IsSmtp
    }
}
