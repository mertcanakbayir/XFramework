
namespace XFramework.Dtos.PageRole
{
    public class PageRoleDto
    {
        public int PageId { get; set; }
        public int RoleId { get; set; }
        public int Id { get; set; }
    }
}