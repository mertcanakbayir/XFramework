namespace XFramework.Dtos.PageRole
{
    public class PageRoleAddDto
    {
        public int PageId { get; set; }
        public int RoleId { get; set; }
    }
}