
namespace XFramework.Dtos.EndpointRole
{
    public class EndpointRoleDto
    {
        public int EndpointId { get; set; }
        public int RoleId { get; set; }
        public int Id { get; set; }
    }
}