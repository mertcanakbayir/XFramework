
namespace XFramework.Dtos.EndpointRole
{
    public class EndpointRoleAddDto
    {
        public int EndpointId { get; set; }
        public int RoleId { get; set; }
    }
}