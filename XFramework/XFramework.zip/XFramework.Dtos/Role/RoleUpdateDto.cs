﻿namespace XFramework.Dtos.Role
{
    public class RoleUpdateDto
    {
        public string Name { get; set; }
    }
}
