﻿namespace XFramework.Dtos.Role
{
    public class RoleAddDto
    {
        public string Name { get; set; }
    }
}
