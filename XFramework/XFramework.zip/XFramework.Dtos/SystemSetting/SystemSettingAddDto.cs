﻿namespace XFramework.Dtos.SystemSetting
{
    public class SystemSettingAddDto
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}
