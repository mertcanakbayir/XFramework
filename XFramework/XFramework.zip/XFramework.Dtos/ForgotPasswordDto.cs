﻿namespace XFramework.Dtos
{
    public class ForgotPasswordDto
    {
        public string Email { get; set; }
    }
}
