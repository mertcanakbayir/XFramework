﻿namespace XFramework.Dtos.SystemSettingDetail
{
    public class SystemSettingDetailUpdateDto
    {
        public string? Key { get; set; }
        public string? Value { get; set; }
        public string? Type { get; set; }
    }
}
