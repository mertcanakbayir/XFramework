﻿namespace XFramework.Dtos.Page
{
    public class PageUpdateDto
    {
        public string PageUrl { get; set; }
        public int Revision { get; set; }
    }
}
