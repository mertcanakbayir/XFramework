﻿namespace XFramework.Dtos.Page
{
    public class PageAddDto
    {
        public string PageUrl { get; set; }

        public int Revision { get; set; }
    }
}
