﻿namespace XFramework.Dtos.Endpoint
{
    public class EndpontUpdateDto
    {
        public string Controller { get; set; }

        public string Action { get; set; }

        public string HttpMethod { get; set; }
    }
}
